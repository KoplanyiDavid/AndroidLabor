package hu.bme.aut.android.telephonydemo

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_send_mms.*
import java.io.File


class SendMMSActivity : Activity() {

    companion object {
        private const val REQUEST_PICKFILE = 1
    }

    private var attachedFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_send_mms)

        // fajl csatolas
        btnAttachFile.setOnClickListener {
            // fajl valasztas Implicit Intent
            val pickFile = Intent()
            pickFile.action = Intent.ACTION_GET_CONTENT
            pickFile.type = "file/*"
            startActivityForResult(pickFile, REQUEST_PICKFILE)
        }

        // MMS kuldes
        btnSendMms.setOnClickListener {
            val phoneNumber = etPhoneNumber.text.toString()
            val messageText = etMessageText.text.toString()

            val attachedFile = attachedFile ?: return@setOnClickListener

            val attachedFileUri: Uri = Uri.fromFile(attachedFile)

            val sendMMSIntent = Intent()
            sendMMSIntent.action = Intent.ACTION_SEND
            sendMMSIntent.putExtra("address", phoneNumber)
            sendMMSIntent.putExtra("sms_body", messageText)
            sendMMSIntent.data = attachedFileUri
            sendMMSIntent.putExtra(Intent.EXTRA_STREAM, attachedFileUri)

            // MIME tipus kideritese
            var mimeType: String? = null
            val extension = MimeTypeMap.getFileExtensionFromUrl(attachedFile.name)
            if (extension != null) {
                mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
            }
            Log.v("MMS", "Mime type: $mimeType")
            sendMMSIntent.type = mimeType

            try {
                startActivity(sendMMSIntent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                        applicationContext,
                        "Nincs MMS küldő alkalmazás!",
                        Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_CANCELED && requestCode == REQUEST_PICKFILE) {
            // Kivalasztott file csatolasa
            val filePath = data.dataString
            attachedFile = File(filePath!!)
            tvAttachedFile.text = attachedFile!!.name
        } else {
            return
        }
    }

}
