package hu.bme.aut.android.telephonydemo

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast


class OutgoingCallReceiver : BroadcastReceiver() {

    @SuppressLint("UnsafeProtectedBroadcastReceiver")
    override fun onReceive(context: Context, intent: Intent) {
        // null vizsgalat
        intent.extras ?: return

        // hivott telefonszam
        val phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER)

        // Toast megjelenitese
        Toast.makeText(
                context,
                "Hivas felugyelo!\n Uj kimeno hivas a kovetkezo szamra: $phoneNumber",
                Toast.LENGTH_LONG).show()
    }

}
