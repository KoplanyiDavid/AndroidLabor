package hu.bme.aut.android.telephonydemo

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telephony.*
import android.telephony.gsm.GsmCellLocation
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ScrollView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : Activity() {

    private lateinit var telephonyManager: TelephonyManager

    private var callPhoneClick: View.OnClickListener = View.OnClickListener { v ->
        // phoneNumber EditText-ben megadott telefonszam tarcsazasa vagy felhivasa
        val phoneNo = etPhoneNumber.text.toString()
        val intent = Intent()
        // Data URI beallitasa: 'tel:[telefonszam]'
        intent.data = Uri.parse("tel:$phoneNo")

        // hivas vagy tarcsazas attol fuggoen, hogy
        // melyik gomb megnyomasara fut le ez a callback
        when (v.id) {
            R.id.btnCallPhone ->
                // ehhez kell a CALL_PHONE permission!
                intent.action = Intent.ACTION_CALL
            R.id.btnDialPhone -> intent.action = Intent.ACTION_DIAL
            else -> {
            }
        }
        // hivas vagy tarcsazas kezdemenyezese a mar osszeallitott implicit Intent-tel
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                    applicationContext,
                    "Nincs telepítve tárcsázó alkalmazás!",
                    Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("MissingPermission", "HardwareIds")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // UI esemenykezelok bekotese (OnClickListener, ...)
        setupUIListeners()

        /* ************************************************** */
        /* ************ TELEFONIA *************************** */

        // 1: TelephonyManager referencia
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        // 2: PhoneStateListener implementacio (eleg hosszu, ezert kulon fuggvenybe kerult)
        val phoneStateListener = setupPhoneStateListener()

        // 3: Telefonia esemenykezelok bekotese - nem szamit a sorrend
        telephonyManager.listen(phoneStateListener,
                PhoneStateListener.LISTEN_CALL_STATE or
                        PhoneStateListener.LISTEN_SIGNAL_STRENGTHS or
                        PhoneStateListener.LISTEN_CALL_FORWARDING_INDICATOR or
                        PhoneStateListener.LISTEN_CELL_LOCATION or
                        PhoneStateListener.LISTEN_DATA_ACTIVITY or
                        PhoneStateListener.LISTEN_DATA_CONNECTION_STATE or
                        PhoneStateListener.LISTEN_MESSAGE_WAITING_INDICATOR or
                        PhoneStateListener.LISTEN_SERVICE_STATE
        )

        // TelephonyManager-tol kozvetlenul lekerdezheto peldaul a SIM kartya allapota.
        when (telephonyManager.simState) {

            TelephonyManager.SIM_STATE_ABSENT -> writeLog("Nincs SIM kurtya a kuszulukben")

            TelephonyManager.SIM_STATE_NETWORK_LOCKED -> writeLog("A mobilszolgaltato letiltotta a kartyat")

            TelephonyManager.SIM_STATE_PIN_REQUIRED -> writeLog("PIN kod megadasa szukseges, csak segelyhivasok")

            TelephonyManager.SIM_STATE_PUK_REQUIRED -> writeLog("PUK kod megadasa szukseges, csak segelyhivasok")

            TelephonyManager.SIM_STATE_READY -> writeLog("A SIM kartya hasznalhato hivas inditasra es fogadasra")

            TelephonyManager.SIM_STATE_UNKNOWN -> writeLog("A kartya allapota nem meghatarozhato")
        }

        // Roaming
        if (telephonyManager.isNetworkRoaming) {
            writeLog("Roaming aktiv, kulfoldi halozat")
        }
        else {
            writeLog("Otthoni halozat")
        }

        // Aktualis szolgaltato neve
        writeLog("Szolgaltato neve: " + telephonyManager.networkOperatorName)

        // Aktualis szolgaltato kodja (MCC + MNC)
        writeLog("Szolgaltato kudja: " + telephonyManager.networkOperator)

        // Hivas allapot
        when (telephonyManager.callState) {
            TelephonyManager.CALL_STATE_RINGING -> writeLog("Uj bejovo hivas (csorog a telefon)")
            TelephonyManager.CALL_STATE_OFFHOOK -> writeLog("Egy vagy tobb hivas van folyamatban, lehet tarcsazas kozben, kapcsolodva vagy tartasban.")
            TelephonyManager.CALL_STATE_IDLE -> writeLog("Nincs aktivitas a mobilhalozaton")
        }

        // Telefonalasra alkalmas modul tipusa + eszkoz azonosito (IMEI / MEID)
        when (telephonyManager.phoneType) {
            TelephonyManager.PHONE_TYPE_GSM -> writeLog("IMEI: " + telephonyManager.deviceId)
            TelephonyManager.PHONE_TYPE_CDMA -> writeLog("MEID: " + telephonyManager.deviceId)
            TelephonyManager.PHONE_TYPE_SIP -> writeLog("SIP radio azonositoja: " + telephonyManager.deviceId)
            TelephonyManager.PHONE_TYPE_NONE -> writeLog("Az eszkozben nincs telefonulusra alkalmas modul")
            else -> writeLog("Ismeretlen telefon modul tipus: " + telephonyManager.phoneType)
        }

        writeLog("SIM kartya szeriaszuma: " + telephonyManager.simSerialNumber)

        writeLog("SIM szolgaltato neve: " + telephonyManager.simOperatorName)
        writeLog("SIM szolgaltato kudja (MCC+MNC): " + telephonyManager.simOperator)

        writeLog("Sajut telefonszam: " + telephonyManager.line1Number)

        writeLog("Hangposta telefonszama: " + telephonyManager.voiceMailNumber)
    }

    /* Sajat PhoneStateListner */
    private fun setupPhoneStateListener(): PhoneStateListener {
        // Ne felejtsuk el elkerni a kovetkezo permission-oket:
        // - READ_PHONE
        // - ACCESS_COARSE_LOCATION (onCellLocationChanged-hez)

        return object : PhoneStateListener() {

            override fun onServiceStateChanged(serviceState: ServiceState) {
                // Otthoni vagy kulfoldi halozaton vagyunk
                val isRoaming = serviceState.roaming
                if (isRoaming) {
                    writeLog("Roaming aktiv")
                }
                else {
                    writeLog("Roaming inaktiv")
                }

                // Halozat valasztas modjanak aktualis beallitasa
                if (serviceState.isManualSelection) {
                    writeLog("Kezi halozatvalsztas van beallitva")
                } else {
                    writeLog("Automatikus halozatvalsztas van beallitva")
                }

                // Szolgaltato hosszu es rovid neve
                val operatorNameLong = serviceState.operatorAlphaLong
                writeLog("Aktualis mobilhalozat szolgaltatojanak hosszu neve: $operatorNameLong")
                val operatorNameShort = serviceState.operatorAlphaShort
                writeLog("Aktualis mobilhalozat szolgaltatojanak rovid neve: $operatorNameShort")

                // Aktualis mobilhalozat szolgaltatojanak numerikus kodja:
                // orszagkod (pontosan 3 szamjegy, Magyarorszag eseten 216)
                // +
                // operator kod (2 vagy 3 szamjegy, elohivoszam, 20/30/70)
                //
                // peldaul: 21630 (Telekom), 21620 (Telenor), 21670 (Vodafone)
                val operatorCode = serviceState.operatorNumeric
                writeLog("Aktualis mobilhalozat szolgaltatojanak kodja (MCC+MNC): $operatorCode")

                when (serviceState.state) {
                    // Csak veszhivasok engedelyezettek (112, 911)
                    ServiceState.STATE_EMERGENCY_ONLY ->
                        writeLog("Kapcsolodva a mobilhalozathoz, de a SIM kartya le van zarva")

                    // Minden hivas engedelyezett
                    ServiceState.STATE_IN_SERVICE ->
                        writeLog("Kapcsolodva a mobilhalozathoz, SIM kartya feloldva")

                    // A kovetkezo esetekben fordulhat elo:
                    // A telefon epp keresi a szolgaltatot ahova regisztralhat
                    // Egyaltalan nem keres szolgaltatot
                    // A kivalasztott szolgaltato visszautasitotta a
                    // regisztracios kerest
                    // Nincs jel a mobilhalozatrol
                    // Jellemzoen "Repulogep uzemmod" eseten
                    ServiceState.STATE_OUT_OF_SERVICE -> writeLog("Nincs kapcsolat a mobilhalozattal")

                    ServiceState.STATE_POWER_OFF -> writeLog("Mobilhalozati modul kikapcsolva")
                }
            }

            override fun onCallForwardingIndicatorChanged(isForwarding: Boolean) {
                super.onCallForwardingIndicatorChanged(isForwarding)

                if (isForwarding) {
                    writeLog("Hivas atiranyitas bekapcsolva")
                } else {
                    writeLog("Hivas atiranyitas kikapcsolva")
                }
            }

            override fun onCallStateChanged(state: Int, incomingNumber: String) {
                super.onCallStateChanged(state, incomingNumber)

                when (state) {
                    TelephonyManager.CALL_STATE_RINGING -> {
                        writeLog("uj bejovo hivas")
                        writeLog("A hivo telefonszama: $incomingNumber")
                    }

                    TelephonyManager.CALL_STATE_OFFHOOK -> writeLog("Egy vagy tobb hivas van folyamatban, lehet tarcsazas kozben, kapcsolodva vagy tartasban.")

                    TelephonyManager.CALL_STATE_IDLE -> writeLog("Nincs aktivitas a mobilhalozaton")
                }
            }

            override fun onDataActivity(direction: Int) {
                super.onDataActivity(direction)

                when (direction) {
                    TelephonyManager.DATA_ACTIVITY_IN -> writeLog("Letoltes zajlik")

                    TelephonyManager.DATA_ACTIVITY_OUT -> writeLog("Feltoltes zajlik")

                    TelephonyManager.DATA_ACTIVITY_INOUT -> writeLog("Mindket iranyban tortenik adatforgalom")

                    TelephonyManager.DATA_ACTIVITY_NONE -> writeLog("Nincs adatforgalom")

                    TelephonyManager.DATA_ACTIVITY_DORMANT -> writeLog("Aktiv adatforgalom, de a fizikai kapcsolat megszakadt")
                }
            }

            override fun onDataConnectionStateChanged(newState: Int) {
                super.onDataConnectionStateChanged(newState)

                when (newState) {
                    TelephonyManager.DATA_CONNECTING -> writeLog("Mobilnet csatlakozas folyamatban")

                    TelephonyManager.DATA_CONNECTED -> writeLog("Mobilnet kapcsolodva")

                    TelephonyManager.DATA_SUSPENDED -> writeLog("A kapcsolat felfuggesztve")

                    TelephonyManager.DATA_DISCONNECTED -> writeLog("Nincs mobilnet kapcsolat")
                }
            }

            override fun onMessageWaitingIndicatorChanged(isNewMessage: Boolean) {
                super.onMessageWaitingIndicatorChanged(isNewMessage)

                if (isNewMessage) {
                    writeLog("Van uj hangposta uzenet")
                } else {
                    writeLog("Nincs uj hangposta uzenet")
                }
            }

            override fun onCellLocationChanged(location: CellLocation) {
                super.onCellLocationChanged(location)

                // castolas GsmLocation objektumma
                // Ha CDMA halozat, akkor CdmaCellLocation legyen!
                val gsmCellLocation = location as GsmCellLocation

                val cellId = gsmCellLocation.cid
                writeLog("uj cella azonosito: $cellId")

                val locationAreaCode = gsmCellLocation.lac
                writeLog("uj terulet azonosito: $locationAreaCode")

//                printNeighboringCells()
            }

            override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {

                // GSM halozat hiba rataja (TS 27.007 8.5 szabvany szerint)
                // 0-7 kozti ertek
                val gsmErrorRate = signalStrength.gsmBitErrorRate
                if (gsmErrorRate > 0) {
                    writeLog("GSM halozat hiba rataja: $gsmErrorRate/7")
                }

                // GSM jelerosseg (TS 27.007 8.5 szabvany szerint)
                // 0-31 kozti ertek
                val gsmSignal = signalStrength.gsmSignalStrength
                if (gsmSignal > 0) {
                    writeLog("GSM jelerosseg: $gsmSignal/31")
                }

                // CDMA halozat eseten az RSSI ertek dBm-ben
                val cdmaRSSI = signalStrength.cdmaDbm
                if (cdmaRSSI > 0) {
                    writeLog("CDMA halozat eseten az RSSI ertek dBm-ben: $cdmaRSSI")
                }

                // CDMA halozat eseten az Ec/Io ertek, dB*10
                val cdmaEcIo = signalStrength.cdmaEcio
                if (cdmaEcIo > 0) {
                    writeLog("CDMA halozat eseten az Ec/Io ertek, dB*10: $cdmaEcIo")
                }

                // EVDO halozat eseten az RSSI ertek dBm-ben
                // (ez a halozat tipus csak az USA-ban hasznalt)
                val evdoRSSI = signalStrength.evdoDbm
                if (evdoRSSI > 0) {
                    writeLog("EVDO halozat eseten az RSSI ertek dBm-ben: $evdoRSSI")
                }

                // EVDO halozat eseten az Ec/Io ertek, dB*10
                // (ez a halozat tipus csak az USA-ban hasznalt)
                val evdoEcIo = signalStrength.evdoEcio
                if (evdoEcIo > 0) {
                    writeLog("EVDO halozat eseten az Ec/Io ertek, dB*10: $evdoEcIo")

                }

                // EVDO halozat eseten a jel-zaj arany
                // erteke 0-8 lehet, 8 a legnagyobb SNR
                // (ez a halozat tipus csak az USA-ban hasznalt)
                val evdoSNR = signalStrength.evdoSnr
                if (evdoSNR > 0) {
                    writeLog("EVDO halozat eseten a jel-zaj arany: $evdoSNR")
                }
            }

        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun writeLog(msg: String) {
        val myDateFormat = SimpleDateFormat("HH:mm:ss")
        tvTelephonyLog.append("[${myDateFormat.format(Date())}] $msg\n")

        // log ablak aljara ugrik
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
    }

//    @SuppressLint("MissingPermission")
//    private fun printNeighboringCells() {
//        val cells = telephonyManager.neighboringCellInfo
//
//        writeLog("Szomszedos cellak\n----------------------------")
//        for (cellInfo in cells) {
//            writeLog("Cell ID: " + cellInfo.cid)
//            writeLog("LAC: " + cellInfo.lac)
//            writeLog("Halozat tipus konstans: " + cellInfo.networkType)
//            writeLog("----------------------------")
//        }
//    }

    private fun setupUIListeners() {
        // a telefonszam feldolgozo gombokra ugyanazt az esemenykezelot kotjuk be
        // majd ott eldontjuk hogy mit kell csinalni a telefonszammal
        btnCallPhone.setOnClickListener(callPhoneClick)
        btnDialPhone.setOnClickListener(callPhoneClick)

        // SMS kuldes Activity-re valtas
        btnGotoSmsActivity.setOnClickListener {
            val i = Intent(applicationContext, SendSMSActivity::class.java)
            startActivity(i)
        }

        // MMS kuldes Activity-re valtas
        btnGotoMmsActivity.setOnClickListener {
            val i = Intent(applicationContext, SendMMSActivity::class.java)
            startActivity(i)
        }

        // a callPhone es dialPhone gombokat csak akkor aktivaljuk, ha a telefonszam mezo nem ures
        etPhoneNumber.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun afterTextChanged(s: Editable) {
                if (s.isNotEmpty()) {
                    btnCallPhone.isEnabled = true
                    btnDialPhone.isEnabled = true
                } else {
                    btnCallPhone.isEnabled = false
                    btnDialPhone.isEnabled = false
                }

            }
        })
    }

}
