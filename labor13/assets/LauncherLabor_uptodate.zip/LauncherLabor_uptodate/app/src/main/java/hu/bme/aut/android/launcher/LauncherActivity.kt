package hu.bme.aut.android.launcher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import hu.bme.aut.android.launcher.adapter.LauncherPagerAdapter
import kotlinx.android.synthetic.main.activity_launcher.*


class LauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)

        vpLauncherPanels.adapter = LauncherPagerAdapter(supportFragmentManager)
        vpLauncherPanels.offscreenPageLimit = 3
    }

}
