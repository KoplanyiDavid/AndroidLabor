package hu.bme.aut.android.placestovisit.data



import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import hu.bme.aut.android.placestovisit.data.converters.DateTypeConverter
import hu.bme.aut.android.placestovisit.data.converters.PlaceTypeConverter

@Database(entities = [Place::class], version = 1, exportSchema = false)
@TypeConverters(DateTypeConverter::class, PlaceTypeConverter::class)
abstract class PlaceDatabase : RoomDatabase() {

    abstract fun placeDao(): PlaceDao

}
