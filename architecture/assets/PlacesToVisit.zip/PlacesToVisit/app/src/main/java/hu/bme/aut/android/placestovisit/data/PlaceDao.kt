package hu.bme.aut.android.placestovisit.data

import androidx.room.*


@Dao
interface PlaceDao {

    @Insert
    fun insertAll(vararg places: Place)

    @Query("SELECT * FROM Place")
    fun getAll(): List<Place>

    @Update
    fun updatePlace(place: Place): Int

    @Delete
    fun delete(place: Place)

}
