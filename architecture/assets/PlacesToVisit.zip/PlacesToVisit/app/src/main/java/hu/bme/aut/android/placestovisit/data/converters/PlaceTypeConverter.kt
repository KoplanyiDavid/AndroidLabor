package hu.bme.aut.android.placestovisit.data.converters


import androidx.room.TypeConverter
import hu.bme.aut.android.placestovisit.data.Place

class PlaceTypeConverter {

    @TypeConverter
    fun toPlaceType(value: Int?): Place.PlaceType {
        return Place.PlaceType.fromInt(value!!)
    }

    @TypeConverter
    fun toInteger(value: Place.PlaceType?): Int? {
        return value?.value
    }

}
